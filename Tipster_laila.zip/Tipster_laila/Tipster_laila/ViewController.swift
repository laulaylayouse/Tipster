//
//  ViewController.swift
//  Tipster_laila
//
//  Created by administrator on 05/12/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

